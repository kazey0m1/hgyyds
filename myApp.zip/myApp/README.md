

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run dev:weapp
```