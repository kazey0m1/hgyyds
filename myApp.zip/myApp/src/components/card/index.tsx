import React ,{useEffect,useState} from 'react'
import Taro from '@tarojs/taro'
import {View,Image,Text} from '@tarojs/components'
import './index.less'
import received from '../../assets/img/received.png'
import line from '../../assets/img/line.png'


export default (props)=>{
    const {value}=props
    return(
        <View className='other-coupon'>
            <Image src={received} className='received'></Image>
            <Image src={line} className='other-line'></Image>
            <View className='other-left-circular'></View>
            <View className='other-right-circular'></View>
            <View className='other-top'>
                <View className='text1'>
                    <View className='left'>{value.money}</View>
                    <View className='right'>元</View>
                </View>
                <View className='text2'>{value.fullReduction}</View>
                <View className='text3'>{value.title}</View>
                <View className='text4'>{value.period}</View>
            </View>
            <View className='bottom'>
                <View className='text'>{value.text}</View>
            </View>
        </View>
    )
}