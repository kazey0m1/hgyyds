import React ,{useEffect,useState} from 'react'
import Taro from '@tarojs/taro'
import {View,Image,Text} from '@tarojs/components'
import './index.less'

export default ()=>{
    const [index,setIndex]=useState(0)
    useEffect(()=>{
     let timer=setInterval(()=>{
           let i=(index+1)%3
           setIndex(i)
        },200)
        setTimeout(() => {
            clearInterval(timer)
        }, 1000);
    })
    return(
        <View className='wrapper-load'>
            <View className={`circular ${index===0?'active':''}`}></View>
            <View className={`circular ${index===1?'active':''}`}></View>
            <View className={`circular ${index===2?'active':''}`}></View>
        </View>
    )
}