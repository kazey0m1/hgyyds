import React ,{useEffect,useState} from 'react'
import Taro from '@tarojs/taro'
import {View,Image,Text} from '@tarojs/components'
import './index.less'
import line from '../../assets/img/line.png'

export default (props)=>{
    const {value,next}=props
    
    return(
        <View className='modal1-mask'>
            <View className='content'>
                <View className='top'>
                    <View className='text1'>微信支付</View>
                    <View className='text2'>{value?.title}</View>
                    <View className='context'>
                        <View className='context-top'>
                            100港币=<Text>85.51人民币</Text>
                        </View>
                        <View className='context-bottom'>
                            市场参考价&nbsp;&nbsp;<Text>85.50人民币</Text>
                        </View>
                    </View>
                </View>
                <View className='bottom'>
                境外线下门店支付时，每单都可享受微信支付
                境外线下门店支付时，每单都可享
                </View>
                <Image src={line} className='line'></Image>
                <View className='left'></View>
                <View className='right'></View>
            </View>
            <View className='button' onClick={()=>{next()}}>领取下一张</View>
        </View>
    )
}