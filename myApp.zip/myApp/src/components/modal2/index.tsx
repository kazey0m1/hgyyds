import React ,{useEffect,useState} from 'react'
import Taro from '@tarojs/taro'
import {View,Image,Text} from '@tarojs/components'
import './index.less'
import line from '../../assets/img/line.png'
import accumulate from '../../assets/img/accumulate.png'

export default (props)=>{
    const { value,next}=props
    const [isShow,setIsShow]=useState(false)
    useEffect(()=>{
        setTimeout(() => {
            setIsShow(true)
        }, 2000);
    })
    
    return(
        <View className='mask'>
            <View className='content'>
                <View className='top'>
                    <View className='text1'>微信支付</View>
                    <View className='text2'>{value?.title}</View>
                    <View className='context'>
                        <View className='context-left'>
                            <View className='wrapper ' >
                            <View>{value?.num-2}</View>
                            <View>{value?.num-1}</View>
                            <View>{value?.num}</View>
                            </View> 
                        </View>
                        <View className='context-right'>元</View>
                    </View>
                    <Image src={accumulate}></Image>
                </View>
                <View className='bottom'>
                使用后，扫不同礼包码，可获得2倍优惠，第5次将出现超级优惠
                </View>
                <Image src={line} className='line'></Image>
                <View className='left'></View>
                <View className='right'></View>
            </View>
           {isShow?<View className='button' onClick={()=>{next()}}>领取更多</View>:''} 
        </View>
    )
}