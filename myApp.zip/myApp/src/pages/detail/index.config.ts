export default{
    navigationBarTitleText:'境外游礼包',
    navigationBarTextStyle:'black',
    navigationStyle:'custom'
}