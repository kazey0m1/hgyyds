import React ,{useEffect,useState} from 'react'
import Taro from '@tarojs/taro'
import {View,Image,Text} from '@tarojs/components'
import './index.less'
import logo from '../../assets/img/logo.png'
import bg from '../../assets/img/bg.png'
import left from '../../assets/img/left.png'
import takeEffect from '../../assets/svg/shengxiao.svg'
import received from '../../assets/img/received.png'
import line from '../../assets/img/line.png'
import OtherCoupon from '../../components/card'
import merchant from '../../assets/img/merchant.png'
import more from '../../assets/img/more.png'
import arrow from '../../assets/img/arrow.png'
import bottom from '../../assets/img/bottom.png'
import Modal1 from '../../components/modal1'
import Modal2 from '../../components/modal2'
const modalData=[{type:1,title:'超优汇率劵'},{type:2,num:3,title:'境外通用劵'}]
interface modal{
    type:number
    num?:number
    title:string
}
export default ()=>{
 const [statusBarHeight,setStatusBarHeight]=useState(0)
 const [otherData,]=useState([
     {money:20,title:'屈臣氏专享劵',fullReduction:'满300元可用',period:'21天内有效',text:'香港地区屈臣氏线下门店可用'},
     {money:50,title:'香港药妆店立减劵',fullReduction:'满300元可用',period:'21天内有效',text:'香港地区药妆种类商户均可使用'},
 ])
 const [currentModal,setCurrentModal]=useState<modal>({type:0,
    title:''})
 const [currentIndex,setCurrentIndex]=useState(0)
  useEffect(()=>{
    Taro.getSystemInfo({
      success: res => setStatusBarHeight(res.statusBarHeight)
    })
    init()
  },[])

  const init=()=>{
    if(modalData.length!==0){
        setCurrentModal(modalData[0])
    }
  }
  
  const next=()=>{
      if(currentIndex===modalData.length-1){
          setCurrentModal({
              type:0,
              title:''

          })
      }else{
        setCurrentModal(modalData[currentIndex+1])
        setCurrentIndex(currentIndex+1)
      }
  }
    return(
        <View>
            <View className='header'>
                <View className='title' style={`margin-top:${statusBarHeight}px`}>境外游礼包</View>
                <Image className='logo' src={logo}></Image>
                <Image className='bg' src={bg}></Image>
            </View>
            <View className='content'>
                <View className='coupon'>
                    <View className='top'>
                        <View className='left'></View>
                        <View className='middle'>微信支付优惠卷</View>
                        <View className='right'>微信支付自动抵扣</View>
                    </View>
                    <View className='super-coupon'>
                        <View className='top'>
                            <Image src={left} className='left'></Image>
                            <Image src={received} className='received'></Image>
                            <Image src={line} className='line'></Image>
                            <View className='text1'>超优汇率劵</View>
                            <View className='text2'>7天内有效</View>
                            <View className='left-circular'></View>
                            <View className='right-circular'></View>
                        </View>
                        <View className='bottom'>
                            <View className='text1'>100港币=85.41人民币</View>
                            <View className='text2'>市场参考价</View>
                            <View className='text3'>85.80人民币</View>
                        </View>
                    </View>
                    <View className='general-coupon'>
                        <Image src={received} className='received'></Image>
                        <Image src={line} className='line'></Image>
                        <View className='left-circular'></View>
                        <View className='right-circular'></View>
                        <View className='top'>
                            <View className='text1'>
                                <View className='left'>3</View>
                                <View className='right'>元</View>
                            </View>
                            <View className='text2'>满300元可用</View>
                            <View className='text3'>境外通用劵</View>
                            <View className='text4'>15天内有效</View>
                        </View>
                        <View className='bottom'>
                            <View className='general-top'>
                                <View className='left'>4张待解锁</View>
                                <View className='right'>使用后扫不同码可解锁下一张</View>
                            </View>
                            <View className='general-middle'></View>
                        </View>
                    </View>
                    {otherData.map((item)=>{
                        return(<OtherCoupon value={item}></OtherCoupon>)
                    })}
                    
                </View>
                <View className='merchant'>
                    <Image src={merchant}></Image>
                </View>
                <View className='more-merchant'>
                    <View className='icon'>
                        <Image src={more}></Image>
                    </View>
                    <View className='more-discount'>更多商家优惠</View>
                    <View  className='arrow'>
                        <Image src={arrow}></Image>
                    </View>
                </View>
                <View className='customer'>
                    <View>活动规则 </View>
                    <View> &nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp; </View>
                    <View> 联系客服</View>
                </View>
            </View>
            <View className='bottom-bar'>
                <Image src={bottom}></Image>
            </View>
            {currentModal.type!==0?(currentModal.type===1?<Modal1 value={currentModal} next={next} />:<Modal2  value={currentModal} next={next}/>):''}
            
            
        </View>
    )
}