export default {
  navigationStyle:'custom'
}
