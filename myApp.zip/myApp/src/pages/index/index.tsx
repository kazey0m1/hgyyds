import React, { useEffect, useState } from 'react'
import { View} from '@tarojs/components'
import Taro from '@tarojs/taro'
import './index.less'
import Load from '../../components/load'

export default ()=>{
  const [statusBarHeight,setStatusBarHeight]=useState(0)
  useEffect(()=>{
    Taro.getSystemInfo({
      success: res => setStatusBarHeight(res.statusBarHeight)
    })
    .then(res => console.log('fail',res))
    setTimeout(function(){
      Taro.navigateTo({url:'/pages/detail/index'})
    },1000)
  },[])
    return (
      <View className='wrapper' style={`margin-top:${statusBarHeight}px`}>
        <View className='icon'></View>
        <View className='title'>境外游礼包</View>
        <Load></Load>
      </View>
    )
}
